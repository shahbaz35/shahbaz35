/**
 * 
 */
/**
 * @author Administrator
 *
 */
module HibernateT {
	requires java.sql;
}